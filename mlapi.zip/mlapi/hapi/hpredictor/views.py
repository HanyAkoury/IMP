from django.shortcuts import render
from .apps import HpredictorConfig
from django.http import JsonResponse
from rest_framework.views import APIView

class call_model(APIView):
    def get(self,request):
        if request.method == 'GET':
            # get sound from request
            sound = request.GET.get('sound')

            # vectorize sound
            vector = HpredictorConfig.vectorizer.transform([sound])
            # predict based on vector
            prediction = HpredictorConfig.regressor.predict(vector)[0]
            # build response
            response = {'dog': prediction}
            # return response
            return JsonResponse(response)
